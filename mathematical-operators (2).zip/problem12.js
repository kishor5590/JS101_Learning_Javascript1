let num=3;
console.log(num**3);