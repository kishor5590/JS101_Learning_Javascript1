let one=1;
let two=2;
let three=3;
console.log(one*two*three);