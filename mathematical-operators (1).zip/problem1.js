let number=2;
    console.log(number*50);


