let name="kishor";
console.log(name);
name="suryanarayana";
console.log(name);
name="muthyalamma";
console.log(name);