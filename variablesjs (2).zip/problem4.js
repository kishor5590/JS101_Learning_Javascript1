console.log( name="studentName   :sai");
console.log( school="school        :delhi public school");
console.log( grade="grade         :B");
console.log( section="section       :A");
console.log(rollno="roll_num      :10");

console.log("subject   marks");
console.log( marks_in_english="english    80");
console.log(marks_in_maths="maths      90");
console.log( marks_in_sanskrit="sanskrit   85");
