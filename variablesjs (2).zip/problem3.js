let name="kishor";
let age=22;
console.log(name,age);
console.log(typeof(name),typeof(age));